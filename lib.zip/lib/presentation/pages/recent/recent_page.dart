import '../../../application/theme_bloc/bloc/theme_bloc.dart';
import 'recent_page_imports.dart';

class RecentPage extends StatelessWidget {
  const RecentPage({super.key});

  List<CardWidget> getCards(List<DetectedLeaf> leafs) {
    List<CardWidget> cards = [];
    for (int i = 0; i < leafs.length; i++) {
      cards.add(CardWidget(
        leafs[i],
        key: Key(leafs[i].coffeeLeafId.toString()),
      ));
    }
    return cards;
  }

  @override
  Widget build(BuildContext context) {
    Widget screen;
    return BlocBuilder<ScannedRecentBloc, ScannedUploadsState>(
        builder: (context, state) {
      if (state is ScannedUploadsLoadingState) {
        screen = Scaffold(
            body: Container(
                color: BlocProvider.of<ThemeBloc>(context).state.whiteColor,
                child: const Center(child: CircularProgressIndicator())));
      } else if (state is ScannedUploadsFailureState) {
        screen = Center(
          child: Column(
            children: [
              const Text('Faild to get recent images'),
              ElevatedButton(
                  onPressed: () {
                    if (state is ScannedUploadsLoadingState) {
                    } else {
                      final recentBloc =
                          BlocProvider.of<ScannedRecentBloc>(context);
                      recentBloc.add(const LoadScannedUploadsEvent());
                    }
                  },
                  style:
                      ElevatedButton.styleFrom(backgroundColor: kPrimaryColor),
                  child: Text(
                    'Retry',
                    style: TextStyle(
                        color: BlocProvider.of<ThemeBloc>(context)
                            .state
                            .whiteColor),
                  ))
            ],
          ),
        );
      } else if (state is ScannedUploadsSuccessState) {
        screen =
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(8, 8, 8, 20),
            child: Text(
              "Recently scanned",
              style: TextStyle(
                  // color: Color.fromRGBO(57, 73, 41, 1),
                  color: kSecondaryColor,
                  fontSize: 20,
                  fontFamily: 'aerial',
                  fontWeight: FontWeight.bold),
            ),
          ),
          state.detectedLeafs.isNotEmpty
              ? Expanded(
                  child: GridView.builder(
                  gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                      maxCrossAxisExtent: 300,
                      mainAxisSpacing: 1,
                      crossAxisSpacing: 2,
                      mainAxisExtent: 220),
                  itemCount: state.detectedLeafs.length,
                  itemBuilder: (BuildContext context, int index) {
                    return CardWidget(
                      state.detectedLeafs[index],
                      key: Key(
                          state.detectedLeafs[index].coffeeLeafId.toString()),
                    );
                  },
                  // children: getCards(state.detectedLeafs),
                ))
              : Column(
                  children: [
                    Center(
                      child: SvgPicture.asset(
                        "assets/icons/scanned_empty.svg",
                        width: MediaQuery.of(context).size.width * .8,
                        height: MediaQuery.of(context).size.height * .5,
                      ),
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                    const Center(
                      child: Text(
                        "No Recently Scanned Images.",
                        textAlign: TextAlign.center,
                        style: TextStyle(color: kPrimaryColor, fontSize: 25),
                      ),
                    )
                  ],
                )
        ]);
      } else {
        screen = const Text('unknown error');
      }
      return screen;
    });
  }
}
