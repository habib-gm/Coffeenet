import 'auth_data_provider_imports.dart';

class AuthDataProvider extends DataProvider {
  Dio dio;
  AuthDataProvider({required this.dio});

  Future<String> login(String username, String password) async {
    try {
      dio.options.headers['content-Type'] = 'application/json';
      final response = await dio.post('$baseUrl/api/token/',
          data: <String, String>{'username': username, 'password': password});
      if (response.statusCode != 200) {
        throw (Exception('Failed to login'));
      }
      var json = response.data;
      return json['access'];
    } catch (e) {
      rethrow;
    }
  }

  Future<bool> register(
      String fullname, String username, String password) async {
    try {
      dio.options.headers['content-Type'] = 'application/json';
      final response = await dio.post('$baseUrl/api/register/',
          data: <String, String>{
            'fullname': fullname,
            'username': username,
            'password': password
          });
      if (response.statusCode != 200) {
        throw (Exception('Failed to register'));
      }
      return true;
    } catch (e) {
      rethrow;
    }
  }
}
