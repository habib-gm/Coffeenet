import '../../../application/theme_bloc/bloc/theme_bloc.dart';
import '../../../application/theme_bloc/state/theme_state.dart';
import '../../constants.dart';
import 'components/popup_menu.dart';
import 'upload_page_imports.dart';
// import 'components/file_card.dart';

class FileUploadPage extends StatefulWidget {
  const FileUploadPage({super.key});

  @override
  State<FileUploadPage> createState() => _FileUploadPageState();
}

class _FileUploadPageState extends State<FileUploadPage> {
  final spinkit = const SpinKitSpinningLines(
    color: kPrimaryColor,
    size: 70.0,
    itemCount: 10,
    lineWidth: 2.0,
  );

  Future<UndetectedLeaf?> _selectFile() async {
    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles();
      if (result != null) {
        String filename = result.files.single.name;
        String filepath = result.files.single.path!;
        double filesize = result.files.single.size / 1024;
        DateTime now = DateTime.now();
        int timestamp = now.millisecondsSinceEpoch;
        UndetectedLeaf undetectedLeaf = UndetectedLeaf(
            filename: filename,
            filesize: filesize.toString(),
            uploadtime: timestamp,
            imagelocation: filepath);

        return undetectedLeaf;
      }
    } catch (e) {
      print("Error selecting file: $e");
    }
    return null;
  }

  List items = [
    // ['user-journey-01.png', 120000, 607],
  ];

  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    double width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
          backgroundColor: kPrimaryColor,
          centerTitle: true,
          elevation: 0,
          title: Text("Upload Image",
              style: TextStyle(
                  color:
                      BlocProvider.of<ThemeBloc>(context).state.whiteColor))),
      body: BlocBuilder<ThemeBloc, ThemeState>(builder: (context, theme) {
        return Container(
          padding: EdgeInsets.all(10),
          color: theme.whiteColor,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            BlocConsumer<UploadBloc, UploadState>(
                listener: (context, statez) async {
              if (statez is UploadSuccessState) {
                // setState(() {
                //   items = state.detectedLeafs;
                //   // items = items;
                // });
                BlocProvider.of<RecentUploadsBloc>(context)
                    .add(const LoadRecentUploadsEvent());
                BlocProvider.of<UploadBloc>(context).emit(InitialUploadState());
                // QuickAlert.show(
                //   context: context,
                //   type: QuickAlertType.success,
                //   title: 'Detection Failed...',
                //   text: 'Sorry, something went wrong.',
                //   confirmBtnColor: Colors.green,
                // );
                await QuickAlert.show(
                  context: context,
                  type: QuickAlertType.success,
                  onConfirmBtnTap: () {
                    // print("confirm tapped");
                    BlocProvider.of<DetailPageBloc>(context).add(
                        LoadDetailPageEvent(leaf: statez.detectedLeafs.last));
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) {
                      return DetailPage();
                    }));
                  },
                  title: 'Detection Done',
                  text: 'Do you want to take a detailed look',
                  confirmBtnText: 'Yes',
                  cancelBtnText: 'No',
                  confirmBtnColor: Colors.green,
                );
              }
              if (statez is UploadFailureState) {
                QuickAlert.show(
                  context: context,
                  type: QuickAlertType.error,
                  title: 'Detection Failed...',
                  text: 'Sorry, something went wrong.',
                  confirmBtnColor: Colors.green,
                );
              }
              if (statez is UploadImageNotLeafState) {
                QuickAlert.show(
                  context: context,
                  type: QuickAlertType.error,
                  title: 'Detection Failed...',
                  text:
                      'The Image Selected is not leaf. Please make sure you selected the correct image.',
                  confirmBtnColor: Colors.green,
                );
              }
            }, builder: (context, state) {
              return Center(
                child: Container(
                  width: width * .9,
                  height: height * .3,
                  child: Center(
                    child: Card(
                      elevation: 7,
                      shadowColor: theme.blackColor,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(24),
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(24),
                        child: Column(
                          children: [
                            Column(children: [
                              Container(
                                  decoration: BoxDecoration(
                                    color: theme.whiteColor,
                                    border: Border(),
                                  ),
                                  width: MediaQuery.of(context).size.width,
                                  child: Container(
                                      padding: const EdgeInsets.fromLTRB(
                                          15, 15, 0, 13),
                                      // height: height * 0.0617,
                                      child: state is UploadLoadingState
                                          ? Text(
                                              "Processing please wait",
                                              textAlign: TextAlign.left,
                                              style: TextStyle(
                                                  color: Color(0xFF1899B4),
                                                  fontSize: 24.43,
                                                  fontWeight: FontWeight.w600),
                                            )
                                          : Text(
                                              "Click below to upload.",
                                              textAlign: TextAlign.left,
                                              style: TextStyle(
                                                  color: kPrimaryColor,
                                                  fontSize: 18,
                                                  fontWeight: FontWeight.w600),
                                            ))),
                            ]),
                            Expanded(
                              child: Container(
                                  // height: height * 0.2,
                                  width: MediaQuery.of(context).size.width,
                                  // color: const Color(0xFFF7F9FB),
                                  color: theme.whiteColor == Color(0xFF121212)
                                      ? Color.fromARGB(50, 247, 249, 251)
                                      : const Color(0xFFF7F9FB),

                                  // color: Colors.red,
                                  child: Center(
                                    child: state is! UploadLoadingState
                                        ? InkWell(
                                            onTap: () async {
                                              UndetectedLeaf? undetectedLeaf =
                                                  await _selectFile();
                                              if (undetectedLeaf != null) {
                                                BlocProvider.of<UploadBloc>(
                                                        context)
                                                    .add(StartUploadEvent(
                                                        leaf: undetectedLeaf,
                                                        scanned: false));
                                              }
                                            },
                                            child: Image(
                                              height: height * 0.12,
                                              width: width * .5,
                                              // fit: BoxFit.fitHeight,
                                              image: const AssetImage(
                                                  'assets/file_upload.png'),
                                            ),
                                          )
                                        : Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              spinkit, // Progress bar widget
                                              SizedBox(
                                                  width:
                                                      10), // Add some spacing between the progress bar and text
                                              Text('Uploading...'
                                                  // style: ,
                                                  ), // Uploading text widget
                                            ],
                                          ),
                                  )),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              );
            }),
            Container(
              width: width * .9,
              // height: height * .5,
              child: Card(
                elevation: 7,
                shadowColor: Colors.grey,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(24),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(24),
                  child: Column(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          color: theme.whiteColor,
                          border: Border(
                              bottom: BorderSide(
                            color: Color.fromARGB(255, 207, 203, 203),
                            width: 1,
                          )),
                        ),
                        width: MediaQuery.of(context).size.width,
                        child: Padding(
                          padding: EdgeInsets.fromLTRB(15, 15, 0, 13),
                          child: Text(
                            "Recent uploads",
                            textAlign: TextAlign.left,
                            style: TextStyle(
                                color: theme.blackColor,
                                fontSize: 20,
                                fontWeight: FontWeight.w600),
                          ),
                        ),
                      ),
                      Container(
                          height: MediaQuery.of(context).size.height * .35,
                          color: theme.whiteColor,
                          width: MediaQuery.of(context).size.width,
                          child: BlocBuilder<RecentUploadsBloc,
                              RecentUploadsState>(builder: (context, state) {
                            return state is RecentUploadsLoadingState
                                ? Center(child: spinkit)
                                : state is RecentUploadsSuccessState
                                    ? ListView.builder(
                                        itemCount: state.detectedLeafs.length,
                                        itemBuilder:
                                            (BuildContext context, int index) {
                                          DateTime now = DateTime.now();
                                          int _timestamp =
                                              now.millisecondsSinceEpoch;
                                          num time = (_timestamp -
                                                  state.detectedLeafs[index]
                                                      .uploadtime) /
                                              60000;
                                          return Column(
                                            textBaseline:
                                                TextBaseline.ideographic,
                                            children: [
                                              ListTile(
                                                  horizontalTitleGap: 0,
                                                  contentPadding:
                                                      const EdgeInsets
                                                              .symmetric(
                                                          vertical: 0.0,
                                                          horizontal: 25),
                                                  leading: const Image(
                                                    image: AssetImage(
                                                        'assets/list_image.png'),
                                                  ),
                                                  style: ListTileStyle.list,
                                                  title: Text(
                                                    state.detectedLeafs[index]
                                                        .filename,
                                                    style: TextStyle(
                                                        color: theme.blackColor,
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        fontSize: 14),
                                                  ),
                                                  subtitle: Text(
                                                      time < 100
                                                          ? '${time.toStringAsFixed(2)} min ago'
                                                          : time < 2400
                                                              ? '${(time / 60).toStringAsFixed(2)} hr ago'
                                                              : time > 24000
                                                                  ? 'more than 10 days ago'
                                                                  : '${(time / (24 * 60)).toStringAsFixed(0)} days ago',
                                                      style: TextStyle(
                                                          color:
                                                              theme.blackColor,
                                                          fontWeight:
                                                              FontWeight.w200,
                                                          fontSize: 12)),
                                                  // trailing: items[index][3],
                                                  trailing: Row(
                                                      mainAxisSize:
                                                          MainAxisSize.min,
                                                      children: [
                                                        Container(
                                                            padding: const EdgeInsetsDirectional
                                                                    .symmetric(
                                                                horizontal: 8,
                                                                vertical: 4),
                                                            decoration: BoxDecoration(
                                                                border: Border.all(
                                                                    color: theme.whiteColor == Colors.white
                                                                        ? const Color.fromARGB(
                                                                            255,
                                                                            207,
                                                                            203,
                                                                            203)
                                                                        : greyColor),
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            5)),
                                                            child: Text(
                                                                '${state.detectedLeafs[index].filesize} kb',
                                                                style: TextStyle(
                                                                  color: theme
                                                                      .blackColor,
                                                                  fontSize: 11,
                                                                ))),
                                                        // popupMenu(context)
                                                        IconButton(
                                                            onPressed: () {},
                                                            icon: Icon(
                                                                Icons.delete,
                                                                color: Colors
                                                                    .red[400]))
                                                      ]),
                                                  onTap: () {
                                                    // print("clicked");
                                                    BlocProvider.of<
                                                                DetailPageBloc>(
                                                            context)
                                                        .add(LoadDetailPageEvent(
                                                            leaf: state
                                                                    .detectedLeafs[
                                                                index]));
                                                    Navigator.push(
                                                      context,
                                                      MaterialPageRoute(
                                                        builder: (context) {
                                                          return DetailPage();
                                                        },
                                                      ),
                                                    );
                                                  }),
                                              index !=
                                                      state.detectedLeafs
                                                              .length -
                                                          1
                                                  ? const Divider(
                                                      thickness: .5,
                                                      indent: 20,
                                                      endIndent: 20,
                                                      color: greyColor,
                                                    )
                                                  : SizedBox()
                                            ],
                                          );
                                        },
                                      )
                                    : Center(
                                        child: Text(
                                        "Error while loading recent uploads",
                                        style: TextStyle(color: Colors.red),
                                      ));
                          })),
                      Container(
                        color: const Color.fromARGB(110, 248, 248, 248),
                        // color: Colors.red,
                        padding: const EdgeInsets.fromLTRB(20, 5, 0, 5),
                        child: const Row(
                          children: [
                            Icon(Icons.done),
                            Text(
                              "  Last time: 3 min ago.",
                              style: TextStyle(fontSize: 12),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ]),
        );
      }),
    );
  }
}
