import 'package:flutter/material.dart';

const kPrimaryColor = Color(0xFFEFBC08);
const kSecondaryColor = Color(0xFFEFBC08);
const kPrimaryLightColor = Color(0xFFF1E6FF);
// const whiteColor = Color(0xFF121212);
// // const whiteColor = Colors.white;
const greyColor = Colors.grey;
// const blackColor = Colors.white;
// // const blackColor = Colors.black;
// const detailPageTextColor = Color(0xFF2C2C2C);

const double defaultPadding = 16.0;
