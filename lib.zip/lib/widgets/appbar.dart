import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../application/theme_bloc/bloc/theme_bloc.dart';
import '../application/theme_bloc/event/theme_event.dart';
import '../presentation/constants.dart';

void _showDialog(BuildContext context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: Text("Alert!!"),
        content: Text("You are awesome!"),
        actions: [
          MaterialButton(
            child: Text("OK"),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
        ],
      );
    },
  );
}

popupMenu(BuildContext context) => PopupMenuButton<int>(
    padding: const EdgeInsets.all(0.0),
    itemBuilder: (context) => [
          // PopupMenuItem 1
          PopupMenuItem(
            enabled: false,
            child: Center(
              child: Text("Jabir Esmael",
                  style: TextStyle(
                      color: BlocProvider.of<ThemeBloc>(context)
                          .state
                          .blackColor)),
            ),
          ),
          PopupMenuItem(
            value: 1,
            // row with 2 children
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.logout, color: Colors.red),
                SizedBox(
                  width: 5,
                ),
                Text("Sign out", style: TextStyle(color: Colors.red))
              ],
            ),
          ),
          // // PopupMenuItem 2
          // PopupMenuItem(
          //   value: 2,
          //   // row with two children
          //   child: Row(
          //     children: [
          //       Icon(Icons.chrome_reader_mode),
          //       SizedBox(
          //         width: 10,
          //       ),
          //       Text(
          //         "About",
          //         style: TextStyle(
          //             color:
          //                 BlocProvider.of<ThemeBloc>(context).state.blackColor),
          //       )
          //     ],
          //   ),
          // ),
        ],
    // offset: Offset(0, 100),
    color: BlocProvider.of<ThemeBloc>(context).state.whiteColor,
    elevation: 2,
    // on selected we show the dialog box
    onSelected: (value) {
      // if value 1 show dialog
      if (value == 1) {
        BlocProvider.of<ThemeBloc>(context).add(ChangeThemeEvent());
        // _showDialog(context);
        // if value 2 show dialog
      } else if (value == 2) {
        _showDialog(context);
      }
    },
    splashRadius: 20,
    icon:
        // Padding(
        //   padding: EdgeInsets.all(8.0),
        //   child: Icon(
        //     BlocProvider.of<ThemeBloc>(context).state is DarkThemeState
        //         ? Icons.light_mode
        //         : Icons.dark_mode,
        //     color: BlocProvider.of<ThemeBloc>(context).state.blackColor,
        //   ),
        // )
        Center(
      child: Center(
        child: CircleAvatar(
            backgroundColor: kPrimaryColor,
            child: Icon(Icons.person_outline_rounded, color: Colors.white)),
      ),
    ));

AppBar getAppBar(BuildContext context) {
  return AppBar(
    toolbarHeight: 60,
    backgroundColor: BlocProvider.of<ThemeBloc>(context).state.whiteColor,
    elevation: 0,
    leading: const Padding(
      padding: EdgeInsets.fromLTRB(6, 1, 0, 0),
      child: Image(image: AssetImage('assets/leaflogo.png')),
    ),
    title: const Text(
      "Arebica Armour",
      style: TextStyle(
        color: Color.fromRGBO(1, 155, 113, 1),
        fontFamily: 'times new roman',
        letterSpacing: 1,
        fontSize: 27,
      ),
    ),
    actions: [
      // Padding(
      //   padding: EdgeInsets.all(8.0),
      //   child: Icon(
      //     Icons.settings_outlined,
      //     color: blackColor,
      //   ),
      // )
      Container(
          margin: const EdgeInsets.only(right: 10.0), child: popupMenu(context))

      // InkWell(
      //   onTap: () {
      //     BlocProvider.of<ThemeBloc>(context).add(ChangeThemeEvent());
      //   },
      //   child: Padding(
      //     padding: EdgeInsets.all(8.0),
      //     child: Icon(
      //       BlocProvider.of<ThemeBloc>(context).state is DarkThemeState
      //           ? Icons.light_mode
      //           : Icons.dark_mode,
      //       color: BlocProvider.of<ThemeBloc>(context).state.blackColor,
      //     ),
      //   ),
      // )
      // Center(
      //   child: Padding(
      //     padding: const EdgeInsets.only(right: 10.0),
      //     child: Center(
      //       child: CircleAvatar(
      //           backgroundColor: kPrimaryColor,
      //           child: Icon(Icons.person_outline_rounded, color: Colors.white)),
      //     ),
      //   ),
      // )
    ],
  );
}
