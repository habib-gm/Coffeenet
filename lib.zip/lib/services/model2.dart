import 'dart:io';
import 'dart:typed_data';
import 'package:image/image.dart' as img;
import 'dart:core';
import 'package:contours/contours.dart'
// import 'package:cv'
import 'package:ml_algo/ml_algo.dart';

// Import tflite_flutter
import 'package:tflite_flutter/tflite_flutter.dart';

class ImageChecker {
  final _classificationModelFile =
      'coffee_leaf_binary_network_efficientnetv2_b0_adam0_0003_batch128.tflite';
  final _segmentationModelFile =
      'coffee_leaf_binary_network_efficientnetv2_b0_adam0_0003_batch128.tflite';

  // TensorFlow Lite Interpreter object
  late Interpreter _classificationModel;
  late Interpreter _segmentationModel;

  ImageChecker() {
    // Load model when the classifier is initialized.
    // print("loading model");
    _loadModel();
  }

  void _loadModel() async {
    // print("loading model...");
    // Creating the interpreter using Interpreter.fromAsset
    _classificationModel = await Interpreter.fromAsset(_classificationModelFile);
    _segmentationModel = await Interpreter.fromAsset(_segmentationModelFile);
    // print(_classificationModel.getInputTensors());
    // print('Interpreter loaded successfully');
  }

Future<List> segmentImage(Uint8List image) async {
  // Load the image and resize it
  var decodedImage = img.decodeImage(image);
  var resizedImage = img.copyResize(decodedImage!, width: 512, height: 256);

  // Apply segmentation model
  var segmentation = List<double>.filled(1, 0).reshape([1,512, 256,2]);
    // print("running Interpreter");
  _segmentationModel.run(resizedImage, segmentation);
  segmentation = segmentation.reshape([131072, 2]);
  segmentation = segmentation.map((arr) => arr.reduce((a, b) => a > b ? a : b)).toList();
  segmentation = segmentation.map((val) => val >= 0.5 ? 1 : 0).toList();
  segmentation = segmentation.map((val) => val * 255).toList() as List<int>;

  // Find contours in the segmented image
  var currDiseases = <String>{};
  var segmentationTyped = Uint8List.fromList(segmentation as List<int>);
  var contours = img.findContours(segmentationTyped);
  for (var cnt in contours) {
    var bbox = img.boundingBox(cnt);
    var x = bbox.left;
    var y = bbox.top;
    var w = bbox.width;
    var h = bbox.height;
    
    // Crop the image and resize it
    var croppedImage = img.copyCrop(resAs the text got cut off, here's the rest of the Dart code:

    var croppedImage = img.copyCrop(resizedImage, x, y, w, h);
    croppedImage = img.copyResize(croppedImage, width: 150, height: 150);

    // Apply classification model
    var output = await classificationModel.predict([croppedImage]);
    var diseaseIndex = output[0].indexOf(output[0].reduce((a, b) => a > b ? a : b));
    var currDisease = diseases[diseaseIndex];

    // Fill the contour with the color corresponding to the predicted disease
    var color = colors[diseaseIndex];
    var filledImage = img.fillPolygon(resizedImage, cnt, color);

    currDiseases.add(currDisease);
  }

  return [img.encodeJpg(resizedImage), currDiseases.toList()];
  }

  Future<List> imageToTensor(File imageFile) async {
    img.Image image = img.decodeImage(imageFile.readAsBytesSync())!;
    img.Image resizedImage = img.copyResize(image, width: 224, height: 224);
    var input = Float32List(1 * 224 * 224 * 3);
    var index = 0;
    for (var i = 0; i < 224; i++) {
      for (var j = 0; j < 224; j++) {
        var pixel = resizedImage.getPixel(j, i);
        input[index++] = pixel.getChannel(img.Channel.red) / 1.0;
        input[index++] = pixel.getChannel(img.Channel.green) / 1.0;
        input[index++] = pixel.getChannel(img.Channel.blue) / 1.0;
      }
    }
    // print(resizedImage.getPixel(4);
    return [
      input.reshape([50176, 3]).reshape([224, 224, 3])
    ];
  }

  runInference(List inputTensor) async {
    // double output = 0;
    var output = List<double>.filled(1, 0).reshape([1, 1]);
    // print("running Interpreter");
    _classificationModel.run(inputTensor, output);
    // print("==================================");
    // print(output);
    // print(output[0][0] <= .2);
    // print(await checkInternetConnection());
    // print(
    // "*******************************************************************************");
    return output[0][0] <= .2;
    // return [output];
  }


Future<List<dynamic>> segmentImage(img.Image image) async {
  img.Image resizedImage = img.copyResize(image, width: 512, height: 256);
  List<List<List<double>>> segmentation = await segmentationModel.predict([resizedImage]);
  List<List<double>> segment = segmentation[0];
  segment = img.normalize(segment as img.Image);
  segment = img.threshold(segment, 0.5, 1.0, 255.0);
  segment = img.grayscale(segment as img.Image);
  List<img.Image> croppedImages = [];
  List<String> currDiseases = [];

  img.Image inputImage = resizedImage;
  for (var i = 0; i < segment.length; i++) {
    img.Image croppedImage = img.copyCrop(inputImage, segment[i][0][0].toInt(), segment[i][0][1].toInt(),
        segment[i][1][0].toInt() - segment[i][0][0].toInt(), segment[i][1][1].toInt() - segment[i][0][1].toInt());
    croppedImage = img.copyResize(croppedImage, width: 150, height: 150);
    croppedImages.add(croppedImage);

    List<double> output = await classificationModel.predict([croppedImage])[0];
    int diseaseIndex = output.indexOf(output.reduce((max, element) => max > element ? max : element));
    String currDisease = diseases[diseaseIndex];
    currDiseases.add(currDisease);
  }

  return [inputImage, currDiseases];
}

}
