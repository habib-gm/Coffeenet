import 'imports.dart';

class ResetPasswordForm extends StatefulWidget {
  const ResetPasswordForm({
    Key? key,
  }) : super(key: key);

  @override
  State<ResetPasswordForm> createState() => _ResetPasswordFormState();
}

class _ResetPasswordFormState extends State<ResetPasswordForm> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _psdController = TextEditingController();
  final TextEditingController _confirmPsdController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    bool showPass = true;
    bool showConfirmPass = true;

    return Form(
      key: _formKey,
      child: Column(
        children: [
          TextFormField(
            controller: _psdController,
            keyboardType: TextInputType.emailAddress,
            textInputAction: TextInputAction.next,
            obscureText: showPass,
            cursorColor: kPrimaryColor,
            validator: (psd) {
              return Validators().isPasswordValid(psd);
            },
            decoration: InputDecoration(
              hintText: "enter your password",
              prefixIcon: const Padding(
                padding: EdgeInsets.all(defaultPadding),
                child: Icon(Icons.mail),
              ),
              suffixIcon: Padding(
                padding: const EdgeInsets.all(defaultPadding),
                child: IconButton(
                    onPressed: () {
                      setState(() {
                        showPass = !showPass;
                      });
                    },
                    icon: showPass
                        ? const Icon(Icons.visibility)
                        // ignore: dead_code
                        : const Icon(Icons.visibility_off)),
              ),
            ),
          ),
          const SizedBox(height: defaultPadding),
          TextFormField(
            controller: _confirmPsdController,
            keyboardType: TextInputType.emailAddress,
            textInputAction: TextInputAction.next,
            cursorColor: kPrimaryColor,
            validator: (psd) {
              return Validators().isPasswordValid(psd);
            },
            obscureText: showConfirmPass,
            decoration: InputDecoration(
              hintText: "confirm your password",
              prefixIcon: const Padding(
                padding: EdgeInsets.all(defaultPadding),
                child: Icon(Icons.mail),
              ),
              suffixIcon: Padding(
                padding: const EdgeInsets.all(defaultPadding),
                child: IconButton(
                    onPressed: () {
                      setState(() {
                        showPass = !showPass;
                      });
                    },
                    icon: showPass
                        ? const Icon(Icons.visibility)
                        : const Icon(Icons.visibility_off)),
              ),
            ),
          ),
          const SizedBox(height: defaultPadding),
          ElevatedButton(
            onPressed: () {
              if (_formKey.currentState!.validate()) {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (context) {
                      return const WelcomeScreen();
                    },
                  ),
                );
              }
            },
            child: Text(
              "Done".toUpperCase(),
            ),
          ),
          const SizedBox(height: defaultPadding),
        ],
      ),
    );
  }
}
