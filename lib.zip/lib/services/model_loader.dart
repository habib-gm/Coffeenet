import 'dart:io';
import 'dart:typed_data';
import 'package:image/image.dart' as img;

// Import tflite_flutter
import 'package:tflite_flutter/tflite_flutter.dart';

class ImageChecker {
  final _modelFile =
      'coffee_leaf_binary_network_efficientnetv2_b0_adam0_0003_batch128.tflite';

  // TensorFlow Lite Interpreter object
  late Interpreter _interpreter;

  ImageChecker() {
    // Load model when the classifier is initialized.
    // print("loading model");
    _loadModel();
  }

  void _loadModel() async {
    // print("loading model...");
    // Creating the interpreter using Interpreter.fromAsset
    _interpreter = await Interpreter.fromAsset(_modelFile);
    // print(_interpreter.getInputTensors());
    // print('Interpreter loaded successfully');
  }

  Future<List> imageToTensor(File imageFile) async {
    img.Image image = img.decodeImage(imageFile.readAsBytesSync())!;
    img.Image resizedImage = img.copyResize(image, width: 224, height: 224);
    var input = Float32List(1 * 224 * 224 * 3);
    var index = 0;
    for (var i = 0; i < 224; i++) {
      for (var j = 0; j < 224; j++) {
        var pixel = resizedImage.getPixel(j, i);
        input[index++] = pixel.getChannel(img.Channel.red) / 1.0;
        input[index++] = pixel.getChannel(img.Channel.green) / 1.0;
        input[index++] = pixel.getChannel(img.Channel.blue) / 1.0;
      }
    }
    // print(resizedImage.getPixel(4);
    return [
      input.reshape([50176, 3]).reshape([224, 224, 3])
    ];
  }

  runInference(List inputTensor) async {
    // double output = 0;
    var output = List<double>.filled(1, 0).reshape([1, 1]);
    // print("running Interpreter");
    _interpreter.run(inputTensor, output);
    // print("==================================");
    // print(output);
    // print(output[0][0] <= .2);
    // print(await checkInternetConnection());
    // print(
    // "*******************************************************************************");
    return output[0][0] <= .2;
    // return [output];
  }
}
