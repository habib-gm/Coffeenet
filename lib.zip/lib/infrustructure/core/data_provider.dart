abstract class DataProvider {
  final _baseUrl = 'http://192.168.0.192:8000';
  get baseUrl => _baseUrl;
}
