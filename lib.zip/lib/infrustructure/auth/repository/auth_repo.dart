// import 'package:arabica_armour_mobile/infrastructure/auth/auth.dart';
import 'auth_repo_imports.dart';

class AuthRepo {
  AuthDataProvider authDataProvider;
  AuthRepo({required this.authDataProvider});
  Future<String> login(String username, String password) async {
    String token = await authDataProvider.login(username, password);
    return token;
  }

  Future<bool> register(
      String fullname, String username, String password) async {
    bool token = await authDataProvider.register(fullname, username, password);
    return token;
  }
}
