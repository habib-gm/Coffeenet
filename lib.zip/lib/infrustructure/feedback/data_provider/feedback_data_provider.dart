import 'feedback_data_provider_imports.dart';

class FeedbackDataProvider extends DataProvider {
  final Dio dio;

  FeedbackDataProvider({required this.dio});

  Future<bool> senFeedback(Feedback feedback) async {
    try {
      FormData formData = FormData.fromMap(feedback.toJson());

      Response response = await dio.post("$baseUrl/feedback", data: formData);

      if (response.statusCode == 200) {
        return true;
      } else {
        throw Exception("Error while sending feedback.");
      }
    } catch (e) {
      rethrow;
    }
  }
}
