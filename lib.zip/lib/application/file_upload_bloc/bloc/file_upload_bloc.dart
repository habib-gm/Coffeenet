// import 'package:flutter/material.dart';
import 'package:arabica_armour_mobile/Exceptions/upload/upload_exceptions.dart';

import '../../../infrustructure/upload/repository/upload_repo.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:hive/hive.dart';

import '../../../core.dart';
import '../../../domain/detected_leaf/detected_leaf.dart';
import '../event/file_upload_event.dart';
import '../state/file_upload_state.dart';

class UploadBloc extends Bloc<UploadEvent, UploadState> {
  UploadRepository uploadRepo;

  UploadBloc({required this.uploadRepo}) : super(InitialUploadState()) {
    on<StartUploadEvent>((event, emit) async {
      emit(UploadLoadingState());
      try {
        final Box<DetectedLeaf> detectedLeafBox = Boxes.getDetectedLeaf();
        final detectedLeaf =
            await uploadRepo.uploadLeaf(event.leaf, event.scanned);
        int key = await detectedLeafBox.add(detectedLeaf);
        detectedLeaf.coffeeLeafId = key.toString();
        detectedLeafBox.put(key, detectedLeaf);
        List<DetectedLeaf> detectedLeafs = detectedLeafBox.values.toList();
        emit(UploadSuccessState(detectedLeafs));
      } on ImageNotLeaf {
        emit(UploadImageNotLeafState());
      } catch (error) {
        // rethrow;
        emit(UploadFailureState());
      }
    });
  }
}
