class Feedback {
  String feedbackId;
  String? email;
  String body;

  static final List<String> hospitalFields = [
    'feedbackId',
    'email',
    'body',
  ];

  Feedback({
    required this.feedbackId,
    this.email,
    required this.body,
  });

  factory Feedback.fromJson(Map<String, dynamic> json) {
    return Feedback(
      feedbackId: json['feedbackId'],
      email: json['email'],
      body: json['body'],
    );
  }

  Map<String, dynamic> toJson() {
    Map<String, dynamic> json = {};
    json['feedbackId'] = feedbackId;
    json['email'] = email ?? "";
    json['body'] = body;
    return json;
  }

  @override
  String toString() {
    return "feedback body $body";
  }
}
