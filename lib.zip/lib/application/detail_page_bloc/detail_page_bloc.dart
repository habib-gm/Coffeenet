export 'bloc/detail_page_bloc.dart';
export 'event/detail_page_event.dart';
export 'state/detail_page_state.dart';