import 'package:arabica_armour_mobile/application/auth_bloc/auth.dart';
import 'package:arabica_armour_mobile/infrustructure/auth/data_provider/auth_data_provider.dart';
import 'package:arabica_armour_mobile/infrustructure/auth/repository/auth_repo.dart';
import 'package:arabica_armour_mobile/lib.dart';
import 'package:arabica_armour_mobile/presentation/pages/Settings/settings_page.dart';
import 'package:arabica_armour_mobile/themes.dart';
import 'package:dio/dio.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'application/registration_bloc/bloc/register_bloc.dart';
import 'application/theme_bloc/bloc/theme_bloc.dart';
import 'application/theme_bloc/event/theme_event.dart';
import 'application/theme_bloc/state/theme_state.dart';
import 'infrustructure/upload/data_provider/upload_data_provider.dart';

import 'application/detail_page_bloc/bloc/detail_page_bloc.dart';
import 'domain/bookmarks/bookmarks.dart';
import 'package:hive_flutter/hive_flutter.dart';

import 'application/file_upload_bloc/bloc/recent_uploads_bloc.dart';
import 'application/file_upload_bloc/event/recent_uploads_event.dart';
import 'infrustructure/upload/repository/upload_repo.dart';
import 'infrustructure/upload/services/upload_data_provider_service.dart';
import 'services/model_loader.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Hive.initFlutter();

  Hive.registerAdapter(DetectedLeafAdapter());
  await Hive.openBox<DetectedLeaf>("DetectedLeaf");
  Hive.registerAdapter(BookmarksAdapter());

  ImageChecker imageChecker = ImageChecker();
  final Dio dio = Dio();
  final UploadService uploadService = UploadService();

  runApp(MultiRepositoryProvider(
    providers: [
      RepositoryProvider(
        create: (context) => UploadRepository(
            uploadDataProvider: UploadDataProvider(
                imageChecker: imageChecker,
                dio: dio,
                uploadService: uploadService)),
      )
    ],
    child: MultiBlocProvider(
      providers: [
        BlocProvider(
            create: (context) => ThemeBloc()..add(const LoadThemeEvent())),
        BlocProvider(
            create: (context) =>
                RecentUploadsBloc()..add(const LoadRecentUploadsEvent())),
        BlocProvider(
          create: (context) =>
              UploadBloc(uploadRepo: context.read<UploadRepository>()),
        ),
        BlocProvider(
          create: (context) =>
              ScannedRecentBloc()..add(const LoadScannedUploadsEvent()),
        ),
        BlocProvider(
          create: (context) => DetailPageBloc(),
        ),
        BlocProvider(
          create: (context) => AuthBloc(
              authRepo: AuthRepo(authDataProvider: AuthDataProvider(dio: dio))),
        ),
        BlocProvider(
          create: (context) => BookmarkBloc(),
        ),
        BlocProvider(
          create: (context) => RegisterationBloc(
              authRepo: AuthRepo(authDataProvider: AuthDataProvider(dio: dio))),
        )
      ],
      child: MyApp(),
    ),
  ));
  // ));
}

class MyApp extends StatelessWidget {
  final _router = GoRouter(initialLocation: '/main', routes: [
    GoRoute(
        path: '/splash',
        name: 'splash',
        builder: (context, state) => const SplashScreen()),
    GoRoute(
      path: '/',
      name: 'main',
      // builder: (context, state) => const WelcomeScreen(),
      builder: (context, state) => Footer2(),
    ),
  ]);

  MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ThemeBloc, ThemeState>(builder: (context, st) {
      return MaterialApp.router(
        debugShowCheckedModeBanner: false,
        title: 'Arabica Armour',
        routeInformationParser: _router.routeInformationParser,
        routerDelegate: _router.routerDelegate,
        darkTheme: darkTheme,
        theme: lightTheme,
        themeMode: st is DarkThemeState ? ThemeMode.dark : ThemeMode.light,
      );
    });
  }
}
