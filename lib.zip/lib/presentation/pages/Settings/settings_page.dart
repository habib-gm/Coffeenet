import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../application/theme_bloc/bloc/theme_bloc.dart';
import '../../../application/theme_bloc/event/theme_event.dart';
import '../../../application/theme_bloc/state/theme_state.dart';
import '../../constants.dart';

class SettingsPage extends StatefulWidget {
  @override
  _SettingsPageState createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ThemeBloc, ThemeState>(builder: (context, _) {
      return Scaffold(
        // appBar: AppBar(
        //   backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        //   elevation: 1,
        //   leading: IconButton(
        //     onPressed: () {
        //       Navigator.of(context).pop();
        //     },
        //     icon: Icon(
        //       Icons.arrow_back,
        //       color: Colors.green,
        //     ),
        //   ),
        // ),
        body: Container(
          padding: EdgeInsets.only(left: 16, top: 25, right: 16),
          child: ListView(
            children: [
              Center(
                child: Text(
                  "Settings",
                  style: TextStyle(
                      fontSize: 25,
                      fontWeight: FontWeight.w500,
                      color:
                          BlocProvider.of<ThemeBloc>(context).state.blackColor),
                ),
              ),
              SizedBox(
                height: 15,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      CircleAvatar(
                        radius: 40,
                        backgroundColor: kPrimaryColor,
                        child: Center(
                          child: Icon(
                            Icons.person,
                            color: Colors.white,
                            size: 50,
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 12,
                      ),
                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Jabir Esmael",
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                color: BlocProvider.of<ThemeBloc>(context)
                                    .state
                                    .blackColor),
                          ),
                          Text(
                            "Jabir_Esmael@gmail.com",
                            style: TextStyle(
                              color: BlocProvider.of<ThemeBloc>(context)
                                  .state
                                  .blackColor,
                              fontSize: 15,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  InkWell(
                    onTap: () {
                      BlocProvider.of<ThemeBloc>(context)
                          .add(ChangeThemeEvent());
                    },
                    child: Padding(
                      padding: EdgeInsets.all(8.0),
                      child: BlocProvider.of<ThemeBloc>(context).state
                              is DarkThemeState
                          ? Icon(Icons.light_mode,
                              color: kPrimaryColor, size: 40)
                          : Icon(Icons.dark_mode,
                              color: BlocProvider.of<ThemeBloc>(context)
                                  .state
                                  .blackColor,
                              size: 40),
                    ),
                  )
                  // Icon(Icons.chevron_right_rounded,
                  //     size: 40, color: kPrimaryColor)
                ],
              ),

              // Padding(
              //   padding: const EdgeInsets.all(10.0),
              //   child: buildAccountOptionRow(
              //       context, "Change password", Icons.lock_outline_rounded),
              // ),
              // buildNotificationOptionRow("Dark Mode", true),
              SizedBox(
                height: 25,
              ),
              Text("Account Settings",
                  style: TextStyle(
                      fontSize: 20,
                      color: BlocProvider.of<ThemeBloc>(context)
                                  .state
                                  .blackColor ==
                              Colors.white
                          ? const Color.fromARGB(255, 197, 196, 196)
                          : BlocProvider.of<ThemeBloc>(context)
                              .state
                              .blackColor)),
              Divider(
                height: 10,
                thickness: 2,
                color: BlocProvider.of<ThemeBloc>(context).state.blackColor ==
                        Colors.white
                    ? greyColor[600]
                    : greyColor[300],
              ),
              SizedBox(
                height: 5,
              ),
              buildAccountOptionRow(
                  context, "Change email", Icons.email_outlined),
              buildAccountOptionRow(
                  context, "Content password", Icons.lock_outline_rounded),
              SizedBox(
                height: 15,
              ),
              Text("More Settings",
                  style: TextStyle(
                      fontSize: 20,
                      color: BlocProvider.of<ThemeBloc>(context)
                                  .state
                                  .blackColor ==
                              Colors.white
                          ? const Color.fromARGB(255, 197, 196, 196)
                          : BlocProvider.of<ThemeBloc>(context)
                              .state
                              .blackColor)),
              Divider(
                height: 10,
                thickness: 2,
                color: BlocProvider.of<ThemeBloc>(context).state.blackColor ==
                        Colors.white
                    ? greyColor[600]
                    : greyColor[300],
              ),
              SizedBox(
                height: 5,
              ),
              buildAccountOptionRow(
                  context, "Give Us Feedback", Icons.feedback_outlined),
              buildAccountOptionRow(
                  context, "About Us", Icons.info_outline_rounded),
              buildAccountOptionRow(
                  context, "Terms And Conditions", Icons.lock_outline_rounded),
              SizedBox(
                height: 5,
              ),
              SizedBox(
                height: 20,
              ),
              Center(
                child: OutlinedButton.icon(
                  // padding: EdgeInsets.symmetric(horizontal: 40),
                  style: ButtonStyle(
                      backgroundColor: MaterialStateColor.resolveWith(
                          (states) => Colors.red)),
                  onPressed: () {},
                  icon: Padding(
                    padding: const EdgeInsets.fromLTRB(8.0, 8, 0, 8),
                    child: Icon(Icons.logout_outlined, color: Colors.red),
                  ),
                  label: Text(
                    "SIGN OUT",
                    style: TextStyle(
                        fontSize: 16, letterSpacing: 2.2, color: Colors.red),
                  ),
                ),
              ),
              SizedBox(
                height: 50,
              ),
            ],
          ),
        ),
      );
    });
  }

  buildNotificationOptionRow(String title, bool isActive) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 5),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w500,
                color: BlocProvider.of<ThemeBloc>(context).state.blackColor),
          ),
          Transform.scale(
              scale: 0.7,
              child: CupertinoSwitch(
                value: isActive,
                onChanged: (bool val) {},
              ))
        ],
      ),
    );
  }

  GestureDetector buildAccountOptionRow(
      BuildContext context, String title, IconData icon) {
    return GestureDetector(
      onTap: () {
        showDialog(
            context: context,
            builder: (BuildContext context) {
              return AlertDialog(
                title: Text(title,
                    style: TextStyle(
                        color: BlocProvider.of<ThemeBloc>(context)
                            .state
                            .blackColor)),
                content: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text("Option 1"),
                    Text("Option 2"),
                    Text("Option 3"),
                  ],
                ),
                actions: [
                  FloatingActionButton(
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      child: Text("Close")),
                ],
              );
            });
      },
      child: ListTile(
        trailing: Icon(
          Icons.arrow_forward_ios,
          color: Colors.grey,
        ),
        leading: Icon(icon, color: kPrimaryColor),
        title:
            //  Row(
            //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
            //   children: [
            //     Row(
            //       children: [
            // Icon(icon, color: kPrimaryColor),
            // SizedBox(width: 5),
            Text(
          title,
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w500,
              color: BlocProvider.of<ThemeBloc>(context).state.blackColor ==
                      Colors.white
                  ? const Color.fromARGB(255, 197, 196, 196)
                  : BlocProvider.of<ThemeBloc>(context).state.blackColor),
          // style: GoogleFonts.oswald(
          //   fontSize: 20,
          //   fontWeight: FontWeight.w500,
          // ),
          //   ),
          // ],
        ),
        // Icon(
        //   Icons.arrow_forward_ios,
        //   color: Colors.grey,
        // ),
        // ],
      ),
      // ),
    );
  }
}
