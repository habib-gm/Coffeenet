import 'package:shared_preferences/shared_preferences.dart';

import '../../../application/theme_bloc/bloc/theme_bloc.dart';
import '../../../application/theme_bloc/state/theme_state.dart';
import '../Settings/settings_page.dart';
import 'main_screen_imports.dart';

class Footer2 extends StatefulWidget {
  const Footer2({super.key});

  @override
  State<Footer2> createState() => _Footer2State();
}

class _Footer2State extends State<Footer2> {
//   Color kPrimaryColor = Color(0xFFEFBC08);
//   Color kSecondaryColor = Color(0xFFEFBC08);
//   Color kPrimaryLightColor = Color(0xFFF1E6FF);
//   Color whiteColor = Color(0xFF121212);
// // Color whiteColor = Colors.white;
//   Color greyColor = Colors.grey;
//   Color blackColor = Colors.white;
// // Color blackColor = Colors.black;
//   Color detailPageTextColor = Color(0xFF2C2C2C);

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  int currentTab = 1;
  final List<Widget> screens = [
    const RecentPage(),
    const SplashScreen(),
    Container(),
    Container()
  ];

  final PageStorageBucket bucket = PageStorageBucket();

  Widget currentScreen = const RecentPage();

  // File? _image;

  final imagePicker = ImagePicker();

  Future<void> getImage() async {
    final image = await imagePicker.pickImage(source: ImageSource.camera);

    setState(() async {
      // print(image?.path);
      // _image = image?.path != null ? File(image!.path) : null;
      if (image != null) {
        int size = await image.length();
        UndetectedLeaf leaf = UndetectedLeaf(
            filename: image.name,
            filesize: (size / 1024).toStringAsFixed(2),
            uploadtime: DateTime.now().microsecondsSinceEpoch,
            imagelocation: image.path);

        // ignore: use_build_context_synchronously
        BlocProvider.of<UploadBloc>(context)
            .add(StartUploadEvent(leaf: leaf, scanned: true));
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ThemeBloc, ThemeState>(builder: (context, st) {
      return LayoutBuilder(
        builder: (context, _) => Scaffold(
          body: PageStorage(bucket: bucket, child: currentScreen),
          appBar: currentTab != 1 ? null : getAppBar(context),
          drawer: const Drawer(
            backgroundColor: Colors.black,
          ),
          floatingActionButton: FloatingActionButton(
            backgroundColor: Colors.green,
            onPressed: getImage,
            child: const Icon(Icons.camera),
          ),
          floatingActionButtonLocation:
              FloatingActionButtonLocation.miniCenterDocked,
          bottomNavigationBar: BottomAppBar(
            shape: const CircularNotchedRectangle(),
            notchMargin: 5,
            child: SizedBox(
              height: 60,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: <Widget>[
                        IconButton(
                          onPressed: () {
                            BlocProvider.of<ScannedRecentBloc>(context)
                                .add(const LoadScannedUploadsEvent());
                            setState(() {
                              currentScreen = const RecentPage();
                              currentTab = 1;
                            });
                          },
                          icon: Icon(Icons.grid_view_sharp,
                              color: currentTab == 1
                                  ? kSecondaryColor
                                  : BlocProvider.of<ThemeBloc>(context)
                                      .state
                                      .blackColor),
                        ),
                        IconButton(
                          onPressed: () {
                            BlocProvider.of<BookmarkBloc>(context)
                                .add(const LoadBookmarkEvent());
                            setState(() {
                              currentScreen = const BookmarkPage();
                              currentTab = 2;
                            });
                          },
                          icon: Icon(
                            Icons.bookmark,
                            color: currentTab == 2
                                ? kSecondaryColor
                                : BlocProvider.of<ThemeBloc>(context)
                                    .state
                                    .blackColor,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        IconButton(
                          onPressed: () {
                            setState(() {
                              currentScreen = FileUploadPage();
                              currentTab = 3;
                            });
                          },
                          icon: Icon(Icons.cloud_upload,
                              color: currentTab == 3
                                  ? kSecondaryColor
                                  : BlocProvider.of<ThemeBloc>(context)
                                      .state
                                      .blackColor),
                        ),
                        IconButton(
                          onPressed: () {
                            setState(() {
                              currentScreen = SettingsPage();
                              currentTab = 4;
                            });
                          },
                          icon: Icon(Icons.settings,
                              color: currentTab == 4
                                  ? kSecondaryColor
                                  : BlocProvider.of<ThemeBloc>(context)
                                      .state
                                      .blackColor),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    });
  }
}
