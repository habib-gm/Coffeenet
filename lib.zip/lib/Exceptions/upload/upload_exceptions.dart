class ImageNotLeaf implements Exception {
  final String message;

  ImageNotLeaf(this.message);

  @override
  String toString() {
    return 'MyAppException: $message';
  }
}
