abstract class RegisterEvents {}

class StartRegistionEvent extends RegisterEvents {
  String fullname;
  String username;
  String password;
  StartRegistionEvent(this.fullname, this.username, this.password);
}
